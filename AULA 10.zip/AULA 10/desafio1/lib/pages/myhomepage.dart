import 'package:flutter/material.dart';
import 'package:desafio1/widget/myappbar.dart';
import 'package:desafio1/widget/mycontainer.dart';
import 'package:desafio1/widget/myelev.dart';
import 'package:desafio1/widget/myfab.dart';
import 'package:desafio1/widget/mytxt.dart';

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  String containerText = "Eu amo Flutter!";

  void updateText(String newText) {
    setState(() {
      containerText = newText;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Desafio Flutter 1",
      home: Scaffold(
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(kToolbarHeight),
          child: const MyAppBar(),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              MyFab(label: 'FloatingActionButton', onPressed: (text) => updateText(text)),
              SizedBox(height: 20),
              MyElev(label: 'ElevatedButton', onPressed: (text) => updateText(text)),
              SizedBox(height: 20),
              MyTxt(label: 'TextButton', onPressed: (text) => updateText(text)),
              SizedBox(height: 20),
              MyContainer(text: containerText),
            ],
          ),
        ),
      ),
    );
  }
}
