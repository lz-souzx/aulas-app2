import 'package:flutter/material.dart';

class MyAppBar extends StatelessWidget {
  const MyAppBar({super.key});

  @override
  Widget build(BuildContext context) {
    return AppBar(
      title: Text("Desafio 1"),
      backgroundColor: Colors.purple,
      centerTitle: true,
    );
  }
}
