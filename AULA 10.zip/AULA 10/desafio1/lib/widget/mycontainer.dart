import 'package:flutter/material.dart';

class MyContainer extends StatefulWidget {
  final String text; // recebe o texto que será exibido

  const MyContainer({super.key, required this.text});

  @override
  State<MyContainer> createState() => _MyContainerState();
}

class _MyContainerState extends State<MyContainer> {
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 200,
      width: double.infinity,
      child: Center(
        child: Text(
          widget.text, 
          style: TextStyle(fontSize: 15),
        ),
      ),
    );
  }
}
