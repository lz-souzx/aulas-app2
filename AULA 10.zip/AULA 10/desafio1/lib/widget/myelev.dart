import 'package:flutter/material.dart';

class MyElev extends StatefulWidget {
  final String label;
  final Function(String)? onPressed;

  const MyElev({super.key, required this.label, this.onPressed});

  @override
  State<MyElev> createState() => _MyElevState();
}

class _MyElevState extends State<MyElev> {
  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: () {
        if (widget.onPressed != null) {
          widget.onPressed!(widget.label);
        }
      },
      child: Text(widget.label),
    );
  }
}
