import 'package:flutter/material.dart';

class MyFab extends StatefulWidget {
  final String label;
  final Function(String)? onPressed;

  const MyFab({super.key, required this.label, this.onPressed});

  @override
  State<MyFab> createState() => _MyFabState();
}

class _MyFabState extends State<MyFab> {
  @override
  Widget build(BuildContext context) {
    return FloatingActionButton.extended(
      onPressed: () {
        if (widget.onPressed != null) {
          widget.onPressed!(widget.label); 
        }
      },
      label: Text(widget.label),
    );
  }
}
