import 'package:flutter/material.dart';

class MyTxt extends StatefulWidget {
  final String label;
  final Function(String)? onPressed;

  const MyTxt({super.key, required this.label, this.onPressed});

  @override
  State<MyTxt> createState() => _MyTxtState();
}

class _MyTxtState extends State<MyTxt> {
  @override
  Widget build(BuildContext context) {
    return TextButton(
      onPressed: () {
        if (widget.onPressed != null) {
          widget.onPressed!(widget.label);
        }
      },
      child: Text(widget.label),
    );
  }
}
