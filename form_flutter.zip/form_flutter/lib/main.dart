import 'package:flutter/material.dart';
import 'package:form_flutter/myapp.dart';

void main() {
  runApp(MyApp());
}

