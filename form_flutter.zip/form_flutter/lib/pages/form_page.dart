import 'package:flutter/material.dart';
import 'package:form_flutter/widgets/my_radio.dart';
import 'package:form_flutter/widgets/my_text_field.dart';

class FormPage extends StatelessWidget {
  const FormPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Formulário Flutter",
        ),
      ),

      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[
              
              Padding(
                padding: EdgeInsets.only(bottom: 8),
                child: Text(
                  "Dados pessoais:",
                  
                ),
              ),

              SizedBox(
                width: double.infinity,
                child: MyTextField(),
              ),

              SizedBox(height: 15),

              SizedBox(
                width: double.infinity,
                child: MyTextField(),
              ),

              SizedBox(height: 15),

              Padding(
                padding: EdgeInsets.only(bottom: 8),
                child: Text(
                  "Gênero:",
                
                ),
              ),
            SizedBox(height: 15),


            Row(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                MyRadio(),
                MyRadio()
              ],
            )
            ],
          ),
        ),
      ),
    );
  }
}