import 'package:flutter/material.dart';
import 'package:form_flutter/widgets/my_botton.dart';
import 'package:form_flutter/widgets/my_checkbox.dart';
import 'package:form_flutter/widgets/my_radio.dart';
import 'package:form_flutter/widgets/my_slider.dart';
import 'package:form_flutter/widgets/my_switch.dart';
import 'package:form_flutter/widgets/my_text_field.dart';
import 'package:form_flutter/widgets/my_title.dart';

class FormPage extends StatelessWidget {
  const FormPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Formulário Flutter",
          //style: GoogleFonts.uchen(),
        ),
      ),
      body: const SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[
              MyTitle(title: "Dados Pessoais:"),
              SizedBox(
                width: double.infinity,
                child: MyTextField(
                  title: "Nome:",
                ),
              ),
              SizedBox(height: 15),
              SizedBox(
                width: double.infinity,
                child: MyTextField(
                  title: "Data de nascimento:",
                ),
              ),
              SizedBox(height: 15),
              MyTitle(title: "Gênero:"),
              SizedBox(height: 15),
              Row(
                //mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  MyRadio(title: "Masculino"),
                  MyRadio(title: "Feminino")
                ],
              ),
              SizedBox(height: 15),
              MyTitle(title: "Preferências:"),
              SizedBox(height: 15),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  MyCheckBox(title: "Música"),
                  MyCheckBox(title: "Maquiagens")
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  MyCheckBox(title: "esportes"),
                  MyCheckBox(title: "Academia")
                ],
              ),
              SizedBox(height: 15),

              MyTitle(title: "Idade:"),

              SizedBox(height: 15),

              MySlider(),

              SizedBox(height: 15),

              MySwitch(title: "Deseja receber notificações?",),

              SizedBox(height: 15),
 
              MyBotton(
              title: "Salvar", 
              icon: Icons.save)


            ],
          ),
        ),
      ),
    );
  }
}
